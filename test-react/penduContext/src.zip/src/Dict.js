/*
Author: Benjamin GRASSART
Date: 02/20

Define all words that are to be used in game. 
You can add any word but put it in capital letter.
*/

var Words=[
    "POGNON",
    "TREFLE",
    "FLOUSE",
    "BROUZOUF",
    "FRAICHE",
    "PLAQUE",
    "FRIC",
    "PATATES",
    "OSEILLE",
    "PEZE",
    "GRISBI",
    "BLE",
    "AVOINE",
    "RADIS",
    "THUNE",
    "ROND"
]

export default Words;
